# MS365 Migration
Automation Project

Its POM based conception automation framework. It’s a combination of different techs:
- Everything is controlled by Maven
- Language JAVA
- Testing framework TesNG
- Reporting and logs Extent reports
- Folder structure
      - Test cases
      - Page object folder
      - Source utilities folder
      - Logs folder
      - Screenshot folder
      - Test Outputs folder
      - pom.xml
      - testing.XML
       
 
- All the dependencies are managed from one SharePoint
- Reference libraries
- System libraries
- Maven dependencies
- Helper class is he one that  drives everything from one location
- Test case are controlled by @notation
- The page object is controlled by page factory tech