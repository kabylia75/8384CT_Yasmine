package RegressionM365OutlookDLPRules2119.TestCases;

public class Test1440_JPMCPromptBlockEmailwithJPMCEarningsReleaseClassification {

}
