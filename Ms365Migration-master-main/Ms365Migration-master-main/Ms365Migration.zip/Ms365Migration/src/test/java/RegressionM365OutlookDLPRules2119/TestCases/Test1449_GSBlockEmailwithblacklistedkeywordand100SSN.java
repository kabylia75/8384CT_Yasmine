package RegressionM365OutlookDLPRules2119.TestCases;

public class Test1449_GSBlockEmailwithblacklistedkeywordand100SSN {

}
