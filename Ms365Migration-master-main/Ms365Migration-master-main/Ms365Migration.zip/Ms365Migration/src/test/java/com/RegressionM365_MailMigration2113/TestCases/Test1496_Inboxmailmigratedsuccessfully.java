package com.RegressionM365_MailMigration2113.TestCases;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.ITestResult;


import com.MailMigration2113PageObject.T_1496_Inboxmailmigratedsuccessfully;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import HelperClass.Helper;

@SuppressWarnings("deprecation")
public class Test1496_Inboxmailmigratedsuccessfully extends Helper{
	
	// creating log object for logging messages to console/main.log file
	private static final Logger logger = LogManager.getLogger(Test1496_Inboxmailmigratedsuccessfully.class);
	// test case ID
	String testID= "Test1496_Inboxmailmigratedsuccessfully";	
	//helper class Object
	Helper report = new Helper();
	

//extentReport configuration	
@BeforeTest
	public void rep() {
		report.extentReportSetup();
	}
	
	
@Test(description="Test1496_Inboxmailmigratedsuccessfully")
	public void logiToInBox() throws Exception {
		test = extent.createTest(testID);
		T_1496_Inboxmailmigratedsuccessfully t_1496_Inboxmailmigratedsuccessfully = new T_1496_Inboxmailmigratedsuccessfully();
		t_1496_Inboxmailmigratedsuccessfully.launchBrowser();
		t_1496_Inboxmailmigratedsuccessfully.loginValidUser(prop.getProperty("username"), prop.getProperty("password"));
		
		}
//Publishing extentReport 		
@AfterMethod
   public void repConfig(ITestResult result) throws IOException {
		report.getResult(result);
		logger.info("Test result sent to extent report");
	}
   
   
  
   
   
   
}
