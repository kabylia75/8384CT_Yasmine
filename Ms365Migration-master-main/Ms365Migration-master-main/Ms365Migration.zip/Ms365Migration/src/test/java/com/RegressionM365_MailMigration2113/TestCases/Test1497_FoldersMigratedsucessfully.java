package com.RegressionM365_MailMigration2113.TestCases;

public class Test1497_FoldersMigratedsucessfully {

}
