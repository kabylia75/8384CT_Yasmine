package RegressionM365_CalendarMigration2116.TestCases;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import CalendarMigration2116PageObject.T_1481_CalendarEntriesPredate;
import HelperClass.Helper;



public class Test1481_CalendarEntriesPredate extends Helper {

	// creating log object for logging messages to console/main.log file
		private static final Logger logger = LogManager.getLogger(Test1481_CalendarEntriesPredate.class);
		// test case ID
		String testID= "Test1481_CalendarEntriesPredate";	
		//helper class Object
		Helper report = new Helper();
		

	//extentReport configuration	
	@BeforeTest
		public void rep() {
			report.extentReportSetup();
		}
		
		
	@Test(description="Test1481_CalendarEntriesPredate")
	 
		public void CalendarEntriesPredate() throws Exception {
			test = extent.createTest(testID);
			T_1481_CalendarEntriesPredate t_1481_CalendarEntriesPredate = new T_1481_CalendarEntriesPredate();
			t_1481_CalendarEntriesPredate.launchBrowser();
			t_1481_CalendarEntriesPredate.loginValidUser(prop.getProperty("username"), prop.getProperty("password"));
			
			}
	//Publishing extentReport 		
	@AfterMethod
	   public void repConfig(ITestResult result) throws IOException {
			report.getResult(result);
			logger.info("Test result sent to extent report");
		}
	
	
	
	
	
}
