package RegressIONM365OutlookCalendar2122.TestCases;

public class Test1388_RescheduleInviteSentFROMM365TO {

}
