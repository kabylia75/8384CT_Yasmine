package RegressIONM365OutlookCalendar2122.TestCases;

public class Test1401_CancelaMeetingRoomInvite {

}
