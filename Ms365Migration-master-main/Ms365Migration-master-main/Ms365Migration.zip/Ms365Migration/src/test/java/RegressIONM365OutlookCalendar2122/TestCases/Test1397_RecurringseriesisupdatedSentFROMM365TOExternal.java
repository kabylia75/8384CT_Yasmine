package RegressIONM365OutlookCalendar2122.TestCases;

public class Test1397_RecurringseriesisupdatedSentFROMM365TOExternal {

}
