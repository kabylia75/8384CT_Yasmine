package RegressIONM365OutlookCalendar2122.TestCases;

public class Test1393_UpdateDescriptionSentFROMM365TOExternal {

}
