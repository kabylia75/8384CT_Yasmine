package RegressIONM365OutlookCalendar2122.TestCases;

public class Test1389_RescheduleInviteSentFROMM365TO {

}
