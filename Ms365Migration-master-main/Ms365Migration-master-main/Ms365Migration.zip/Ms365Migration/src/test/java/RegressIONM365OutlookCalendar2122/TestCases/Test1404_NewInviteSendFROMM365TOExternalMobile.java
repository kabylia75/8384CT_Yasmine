package RegressIONM365OutlookCalendar2122.TestCases;

public class Test1404_NewInviteSendFROMM365TOExternalMobile {

}
