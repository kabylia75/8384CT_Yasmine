package OutlookDLPRules2119PageObject;

public class T_1435_UBSBlockNotifyEmailSenttoUnapprovedDomainsEmailBody {

}
