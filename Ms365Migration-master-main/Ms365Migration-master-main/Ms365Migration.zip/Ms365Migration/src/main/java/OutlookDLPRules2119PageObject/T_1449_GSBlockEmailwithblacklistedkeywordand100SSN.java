package OutlookDLPRules2119PageObject;

public class T_1449_GSBlockEmailwithblacklistedkeywordand100SSN {

}
