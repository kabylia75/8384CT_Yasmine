package OutlookDLPRules2119PageObject;

public class T_1448_GSBlockEmailwithblacklistedkeywordand100SSN {

}
