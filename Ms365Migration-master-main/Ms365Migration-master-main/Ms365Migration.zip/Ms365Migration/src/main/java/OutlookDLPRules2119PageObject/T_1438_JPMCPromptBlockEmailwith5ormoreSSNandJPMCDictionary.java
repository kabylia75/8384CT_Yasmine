package OutlookDLPRules2119PageObject;

public class T_1438_JPMCPromptBlockEmailwith5ormoreSSNandJPMCDictionary {

}
