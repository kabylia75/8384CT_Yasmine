package OutlookDLPRules2119PageObject;

public class T_1433_UBSBlockNotifyEmailSenttoUnapprovedDomainsEmailBody {

}
